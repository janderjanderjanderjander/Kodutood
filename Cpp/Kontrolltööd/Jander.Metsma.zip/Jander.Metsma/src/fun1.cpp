#include "fun1.h"

string tulemus(string massiiv[], int mitu) {
    int maxcount = 0; 
    string tagastus; 
    for (int i = 0; i < mitu; i++) { 
        int count = 0; 
        for (int j = 0; j < mitu; j++) { 
            if (massiiv[i] == massiiv[j]) 
                count++; 
        } 
  
        if (count > maxcount) { 
            maxcount = count; 
            tagastus = massiiv[i]; 
        } else if (count == maxcount && massiiv[i] != tagastus) {
            tagastus = "Viik";
        }
    } 
  
    return tagastus; 
} 
