#include <iostream>
#include "fun1.h"
#include "fun2.h"
#include "fun3.h"


int main(int argc, char *argv[]){

	/* ÜL 1
	string varavaLoojaKlubi[]{"Flora", "Levadia", "Flora", "Levadia"};
	cout << tulemus(varavaLoojaKlubi, 4);
	*/

	/* ÜL 2
	teemad<3>("teemad.txt");
	*/
	
	/* ÜL 3
	Aiand aiand{"Luunja-1"};
	Tootaja* t1 = aiand.lisaTootaja("Juhan");
	Tootaja* t2 = aiand.lisaTootaja("Jaak");
	t1->lisaPeenar("Pikk kurk", 25, false);
	t1->lisaPeenar("tomat", 15, "true");
	t1->lisaPeenar("tomat", 15, "true");
	t2->lisaPeenar("tomat-hiline", 40, true);
	aiand.kastaHommikul();
	*/
	return 0; }
