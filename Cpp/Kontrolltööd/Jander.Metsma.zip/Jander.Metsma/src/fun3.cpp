#include "fun3.h"
#include <iostream>
#include <algorithm>

Peenar::Peenar(string m_nimi, unsigned m_mitu, bool kas) {
    nimi = m_nimi;
    arv = m_mitu;
    kasKasta = kas;
};

Peenar::~Peenar() {
    std::cout << nimi << " " << arv << " destruktoris.\n";
}

ostream& operator << (ostream& os, const Peenar& peenar)
{
    string pool = peenar.nimi + " ";
    os << pool;
    os << to_string(peenar.arv);
    return os;
}

Tootaja::Tootaja(string m_nimi) {
    nimi = m_nimi;
}

Tootaja::~Tootaja() {
    for (Peenar* peenra_ptr : omab) {
        delete peenra_ptr;
    }
    cout << nimi << " destructoris" << endl;
}

void Tootaja::lisaPeenar(string vili, unsigned mitu, bool kas) {
    if (!omab.empty()) {
        for (Peenar* peenra_ptr : omab) {
            if (peenra_ptr->nimi == vili && peenra_ptr->arv == mitu) {
                cout << "Peenart ei lisatud" << endl;
                return;
            }
        }
    }
    Peenar* peenar = new Peenar(vili, mitu, kas);
    omab.push_back(peenar);
    cout << "Peenar lisatud: " << *peenar << " Kas kasta?: " << peenar->kasKasta << endl;
}

Aiand::Aiand(string m_nimi) {
    nimi = m_nimi;
}

Tootaja* Aiand::lisaTootaja(string t_nimi) {
    Tootaja* vend = new Tootaja(t_nimi);
    elab.push_back(vend);
    return vend;
}

void Aiand::kastaHommikul() {
    for (Tootaja* tooline_ptr : elab) {
        for (Peenar* peenar_ptr : tooline_ptr->omab) {
            if (peenar_ptr->kasKasta == true) {
                std::cout << "Kastetud hommikul: " << *peenar_ptr << "; t66taja: " << tooline_ptr->nimi << endl;
            }
        }
    }
}

Aiand::~Aiand() {
    for (Tootaja* tootaja_ptr : elab) {
        delete tootaja_ptr;
    }
    cout << nimi << " destructoris" << endl;
}
