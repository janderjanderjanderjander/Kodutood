#pragma once
#include <string>
#include <vector>
using namespace std;

struct Peenar
{
    string nimi;
    unsigned arv;
    bool kasKasta;

Peenar(string, unsigned, bool);
friend ostream& operator << (ostream& os, const Peenar& peenar);
~Peenar();
};

struct Tootaja
{
    string nimi;
    vector<Peenar*> omab;

Tootaja(string);
void lisaPeenar(string, unsigned, bool);
~Tootaja();
};

struct Aiand
{
    string nimi;
    vector<Tootaja*> elab;

Aiand(string);
Tootaja* lisaTootaja(string);
void kastaHommikul();
~Aiand();
};