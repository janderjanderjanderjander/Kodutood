#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <iostream>

using namespace std;

template <int T>
void teemad(string failinimi) {
    int palju{};
    string sisestus;
    cout << "Sisesta s6na osa:";
    cin >> sisestus;
    ifstream failis(failinimi);
    string rida;
    if (failis.is_open()) { 
        while (getline(failis, rida)) { 
            palju++;
        } 
        cout << "Failist " << failinimi << " loeti " << palju << " teemat.\n";
        cout << "Sobivad on j2rgmised:\n";
        failis.clear();
        palju = 0;
        failis.seekg(0, ios::beg);
        while (getline(failis, rida)) { 
            if (rida.find(sisestus) != string::npos) {
                cout << rida << endl;
                palju++;
            }
        }
        cout << "Sobivad " << palju << " teemat.";
        failis.close(); 
}
}